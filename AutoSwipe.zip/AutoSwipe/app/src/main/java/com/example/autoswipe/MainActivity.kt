package com.example.autoswipe

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        fun slider(label: String, key: String, max: Int, def: Int, min: Int = 0) {
            val tv = TextView(this)
            val sb = SeekBar(this).apply { this.max = max; progress = prefs.getInt(key, def) }
            tv.text = "$label: ${sb.progress}"
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    val v = p.coerceAtLeast(min)
                    tv.text = "$label: $v"
                    prefs.edit().putInt(key, v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
            col.addView(tv); col.addView(sb, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        slider("Distância do arrasto (dp)", "distance", 600, 150, 10)
        slider("Duração do arrasto (ms) - menor = mais rápido", "duration", 2000, 150, 10)
        slider("Segurar no final (ms) - 0 = soltar logo", "hold", 3000, 0, 0)

        col.addView(Button(this).apply {
            text = "Ativar serviço de acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(TextView(this).apply {
            text = "\nAtive 'AutoSwipe' na lista. Vão aparecer dois círculos:\n" +
                "• VERMELHO (gatilho): toque nele (ou mapeie a tecla do mouse no GG Mouse Pro). " +
                "Bolinha azul = mover o gatilho.\n" +
                "• VERDE (alvo): coloque em cima do botão de tiro do jogo. O arrasto para cima começa aqui. " +
                "Bolinha amarela = liga/desliga o modo de mover o alvo."
        })
        setContentView(col)
    }
}
