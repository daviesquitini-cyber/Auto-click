package com.example.autoswipe

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout

class SwipeService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var lp: WindowManager.LayoutParams
    private var sizePx = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sizePx = dp(80)

        root = FrameLayout(this)

        // Botão principal (o "botão de tiro")
        val fire = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(110, 255, 60, 60))
                setStroke(dp(2), Color.WHITE)
            }
        }
        root.addView(fire, FrameLayout.LayoutParams(sizePx, sizePx))

        // Alça pequena para mover o botão
        val handle = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(200, 40, 140, 255))
            }
        }
        root.addView(handle, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.TOP or Gravity.END))

        lp = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 300; y = 600
        }

        // Toque no botão = dispara o arrasto para cima
        fire.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) swipeUp()
            true
        }

        // Arrastar a alça = move o botão
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }

        wm.addView(root, lp)
    }

    private var busy = false   // evita disparos sobrepostos (nada de arrasto infinito)

    private fun swipeUp() {
        if (busy) return          // um arrasto por clique, sem repetir
        busy = true

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val dist = dp(prefs.getInt("distance", 150)).toFloat()
        val swipeMs = prefs.getInt("duration", 150).toLong()   // velocidade
        val holdMs = prefs.getInt("hold", 0).toLong()          // tempo segurando no final

        val cx = lp.x + sizePx / 2f
        val cy = lp.y + sizePx / 2f
        val endY = (cy - dist).coerceAtLeast(0f)

        val path = Path().apply { moveTo(cx, cy); lineTo(cx, endY) }
        val s1 = GestureDescription.StrokeDescription(path, 0, swipeMs, holdMs > 0)

        setTouchable(false)   // deixa o gesto atravessar o botão e chegar no jogo
        dispatch(s1) { ok ->
            if (ok && holdMs > 0) {
                val endPath = Path().apply { moveTo(cx, endY) }
                dispatch(s1.continueStroke(endPath, 0, holdMs, false)) { finish() }
            } else finish()
        }
    }

    private fun dispatch(
        stroke: GestureDescription.StrokeDescription,
        done: (Boolean) -> Unit
    ) {
        val g = GestureDescription.Builder().addStroke(stroke).build()
        val sent = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) = done(true)
            override fun onCancelled(d: GestureDescription?) = done(false)
        }, null)
        if (!sent) done(false)
    }

    private fun finish() {
        busy = false
        setTouchable(true)
    }

    private fun setTouchable(touchable: Boolean) {
        lp.flags = if (touchable)
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(root, lp)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }
}
