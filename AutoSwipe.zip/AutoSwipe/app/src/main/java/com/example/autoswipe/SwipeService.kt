package com.example.autoswipe

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.Toast

/**
 * Dois elementos na tela:
 *  - GATILHO (vermelho): é nele que você clica (ou mapeia a tecla do mouse no GG Mouse Pro).
 *  - ALVO (verde): fica em cima do botão de tiro do jogo. O arrasto para cima começa aqui.
 */
class SwipeService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var trigRoot: FrameLayout
    private lateinit var trigLp: WindowManager.LayoutParams
    private lateinit var targRoot: FrameLayout
    private lateinit var targLp: WindowManager.LayoutParams
    private var trigSize = 0
    private var targSize = 0
    private var editTarget = false   // true = alvo pode ser arrastado
    private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun circle(fill: Int, stroke: Int, strokeDp: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        setStroke(dp(strokeDp), stroke)
    }

    override fun onServiceConnected() {
        if (::trigRoot.isInitialized) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        trigSize = dp(80)
        targSize = dp(56)

        buildTarget()
        buildTrigger()
    }

    // ---------- ALVO (verde) ----------
    private fun buildTarget() {
        targRoot = FrameLayout(this)
        val v = View(this).apply { background = circle(Color.argb(70, 0, 220, 90), Color.GREEN, 3) }
        targRoot.addView(v, FrameLayout.LayoutParams(targSize, targSize))
        targRoot.alpha = 0.6f

        targLp = WindowManager.LayoutParams(
            targSize, targSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 600; y = 500 }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        targRoot.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = targLp.x; sy = targLp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    targLp.x = sx + (e.rawX - tx).toInt()
                    targLp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(targRoot, targLp)
                }
            }
            true
        }
        wm.addView(targRoot, targLp)
    }

    // ---------- GATILHO (vermelho) ----------
    private fun buildTrigger() {
        trigRoot = FrameLayout(this)

        val fire = View(this).apply { background = circle(Color.argb(120, 255, 60, 60), Color.WHITE, 2) }
        trigRoot.addView(fire, FrameLayout.LayoutParams(trigSize, trigSize))

        // bolinha azul = mover o gatilho
        val move = View(this).apply { background = circle(Color.argb(220, 40, 140, 255), Color.WHITE, 1) }
        trigRoot.addView(move, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.END))

        // bolinha amarela = liga/desliga o modo "mover alvo"
        val edit = View(this).apply { background = circle(Color.argb(220, 255, 200, 0), Color.WHITE, 1) }
        trigRoot.addView(edit, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.END))

        trigLp = WindowManager.LayoutParams(
            trigSize, trigSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags(),
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 150; y = 500 }

        fire.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) swipeUp()
            true
        }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        move.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = trigLp.x; sy = trigLp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    trigLp.x = sx + (e.rawX - tx).toInt()
                    trigLp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(trigRoot, trigLp)
                }
            }
            true
        }

        edit.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                editTarget = !editTarget
                targRoot.alpha = if (editTarget) 1f else 0.6f
                applyTargetTouchable(editTarget)
                toast(if (editTarget) "Alvo: pode mover" else "Alvo: travado")
            }
            true
        }

        wm.addView(trigRoot, trigLp)
    }

    private fun baseFlags() =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun applyTargetTouchable(touchable: Boolean) {
        targLp.flags = if (touchable) baseFlags()
        else baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(targRoot, targLp)
    }

    // ---------- ARRASTO ----------
    private fun swipeUp() {
        if (busy) return          // um arrasto por clique, nunca infinito
        busy = true

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val dist = dp(prefs.getInt("distance", 150)).toFloat()
        val swipeMs = prefs.getInt("duration", 150).toLong()   // velocidade
        val holdMs = prefs.getInt("hold", 0).toLong()          // segurar no final

        // centro real do alvo na tela
        val loc = IntArray(2)
        targRoot.getLocationOnScreen(loc)
        val cx = loc[0] + targSize / 2f
        val cy = loc[1] + targSize / 2f
        val endY = (cy - dist).coerceAtLeast(0f)

        val path = Path().apply { moveTo(cx, cy); lineTo(cx, endY) }
        val s1 = GestureDescription.StrokeDescription(path, 0, swipeMs, holdMs > 0)

        applyTargetTouchable(false)   // gesto atravessa o alvo e chega no jogo
        dispatch(s1) { ok ->
            if (ok && holdMs > 0) {
                val endPath = Path().apply { moveTo(cx, endY) }
                dispatch(s1.continueStroke(endPath, 0, holdMs, false)) { finish() }
            } else finish()
        }
    }

    private fun dispatch(stroke: GestureDescription.StrokeDescription, done: (Boolean) -> Unit) {
        val g = GestureDescription.Builder().addStroke(stroke).build()
        val sent = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) = done(true)
            override fun onCancelled(d: GestureDescription?) { toast("Arrasto cancelado"); done(false) }
        }, null)
        if (!sent) { toast("Android recusou o gesto"); done(false) }
    }

    private fun finish() {
        busy = false
        applyTargetTouchable(editTarget)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        if (::trigRoot.isInitialized) wm.removeView(trigRoot)
        if (::targRoot.isInitialized) wm.removeView(targRoot)
        super.onDestroy()
    }
}
