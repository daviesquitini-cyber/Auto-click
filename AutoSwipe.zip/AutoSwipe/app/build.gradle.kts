plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.autoswipe"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.autoswipe"
        minSdk = 26   // segurar no final do arrasto exige Android 8.0+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    kotlinOptions { jvmTarget = "17" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
